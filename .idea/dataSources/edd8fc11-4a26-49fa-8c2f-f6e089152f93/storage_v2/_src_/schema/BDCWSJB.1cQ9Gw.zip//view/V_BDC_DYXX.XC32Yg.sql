create view V_BDC_DYXX as
select
  b.YWH ,--业务号
  b.BDCDYH,-- 不动产单元号
  b.DYBDCLX,--抵押不动产类型
  b.DYR,-- 抵押人
  b.DYFS,-- 抵押方式
  b.DJLX,--登记类型
  b.DJYY,-- 登记原因
  b.ZJJZWZL,--在建建筑物坐落
  b.ZJJZWDYFW,--在建建筑物抵押范围
  b.BDBZZQSE,-- 被担保主债权数额
  b.ZWLXQSSJ,-- 债务履行起始时间
  b.ZWLXJSSJ,-- 债务履行结束时间
  b.ZGZQQDSS,-- 最高债权确定事实
  b.ZGZQSE,-- 最高债权数额
  b.ZXDYYWH,-- 注销抵押业务号
  b.ZXDYYY,-- 注销抵押原因
  b.ZXSJ,-- 注销时间
  b.BDCDJZMH,-- 不动产登记证明号
  b.QXDM,-- 区县代码
  b.DJJG,-- 登记机构
  b.DBR,--登簿人
  b.DJSJ,-- 登记时间
  b.FJ,--附记
  b.QSZT,-- 权属状态
  b.DYSW,-- 抵押顺位
  b.ISZZ,-- 是否总证
  b.DYBW,-- 抵押部位
  b.DYMJ,-- 抵押面积
  b.ISBLFLAG,--是否补录，1：是，0：否
  b.ISLHDYSAMEFLAG,-- 是否为联合抵押发一本证标志 1是，其他否
  b.TSRQ--推送日期
  from   BDC_DYAQ b
/

