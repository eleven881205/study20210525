create procedure p_ryywcx(p_aac002 in varchar2,p_aac003 in varchar2,p_page in varchar2,p_size in varchar2,ce08_cursor OUT sys_refcursor) is

/**
人员业务查询
*/

cursor c_ce09(c_aac002 in varchar2,c_aac003 in varchar2) is
  select * from ce09 where sac100 = (select sac100 from cc01 where aac002=c_aac002 and aac003=c_aac003);

 l_count number:=0;

 l_sac100 varchar2(20);

 l_begin number;

 l_end number;

begin

   select count(1) into  l_count from cc01 where aac002=p_aac002 and aac003=p_aac003;

   if(l_count =1) then
      select sac100 into  l_sac100 from cc01 where aac002=p_aac002 and aac003=p_aac003;
   else
      return;
   end if;

   --删除已有的历史数据
   delete from ce08 where sac100 = l_sac100;

   --循环ce09表，根据业务类型数据插入ce08表
   for c in c_ce09(p_aac002,p_aac003) loop

     if(c.caa001 ='GZ') then
         insert into ce08(sac100, cae017, caa002,aae036, caa003,cae075)
         select c.sac100 ,c.cae017,'GZ',ce03.aae036,
            (select aaa103 from aa10 where aa10.aaa102= ce03.cae006 and aa10.aaa100='CAE006' ) caa003,
            (select aaa103 from aa10 where aa10.aaa102= ce03.cae033 and aa10.aaa100='CAE033') cae075
         from ce03 where cae005=c.cae017;

     elsif (c.caa001 ='DY') then
           insert into ce08(sac100, cae017, caa002,aae036, caa003,cae075)
           select c.sac100 ,c.cae017,'DY',ce30.aae036,'抵押业务',
              (select aaa103 from aa10 where aa10.aaa102= ce30.cae073 and aa10.aaa100='CAE073') cae075
           from ce30 where cay007=c.cae017;
     else
        continue;
     end if;

   end loop;

   commit;

   if(p_page<1) then
      l_begin := 0;
      l_end := p_size;
   else
      l_begin := (p_page-1)*p_size+1;
      l_end := p_page * p_size;
   end if;

   OPEN ce08_cursor FOR
   select * from (select row_.* ,rownum rown  from (
    SELECT * FROM ce08 WHERE sac100 = l_sac100 order by aae036 desc
    ) row_ where rownum <= l_end )where rown >=l_begin;


  EXCEPTION
      when others then
        RAISE_APPLICATION_ERROR(-20003,'人员业务查询失败',false);


end p_ryywcx;
/

