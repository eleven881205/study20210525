create function get_chinese
(
  p_name    in varchar2,
  p_chinese in varchar2  --1：汉字，2：数字
) return varchar2
as
  v_code         varchar2(4000) := '';
  v_chinese      varchar2(4000)  := '';
  v_non_chinese  varchar2(4000)  := '';
  v_comma        pls_integer;
  v_code_q       pls_integer;
  v_code_w       pls_integer;

  v_sz varchar2(4000)  := '';

  v_index number;
  v_name varchar2(4000);

begin
  if p_name is not null then

  select  instr(p_name,' ',1,1) into v_index from dual;

  if(v_index >0) then
    select substr(p_name,0,instr(p_name,' ',1,1)) into v_name from dual;
  else
     v_name:=p_name;
  end if;


    -- v_code 替换为字符串对应的
  select replace(substrb(dump(v_name,1010),instrb(dump(v_name,1010),'ZHS16GBK:')),'ZHS16GBK: ','') into v_code from dual where rownum=1;
  for i in 1..length(v_name) loop
      if lengthb(substr(v_name,i,1))=2 then
         v_comma  := instrb(v_code,',');
         v_code_q := to_number(substrb(v_code,1,v_comma-1));
         v_code_w := to_number(substrb(v_code,v_comma+1,abs(instrb(v_code,',',1,2)-v_comma-1)));
         if v_code_q>=176 and v_code_q<=247 and v_code_w>=161 and v_code_w<=254 then
            v_chinese := v_chinese||substr(v_name,i,1);
         else
            v_non_chinese := v_non_chinese||substr(v_name,i,1);
         end if;
         v_code := ltrim(v_code,'1234567890');
         v_code := ltrim(v_code,',');
      else
         v_sz:= substr(p_name,i,1);
         if(v_sz='0' or v_sz='1' or v_sz='2' or v_sz='3' or v_sz='4' or v_sz='5' or v_sz='6' or
             v_sz='7' or v_sz='8' or v_sz='9' or v_sz='X' or v_sz='x') then
            v_non_chinese := v_non_chinese||substr(v_name,i,1);
         end if;
      end if;
      v_code := ltrim(v_code,'1234567890');
      v_code := ltrim(v_code,',');
  end loop;
  if p_chinese = '1' then
     return v_chinese;
  else
     return v_non_chinese;
  end if;
  else
     return '';
  end if;
end;
/

