create procedure test_xj(s_slbh in varchar2,s_ywname out varchar2) is
begin
    select v.ywname into s_ywname from view_bdcapp_ywbljdxx_local v where v.slbh=s_slbh;
end test_xj;
/

