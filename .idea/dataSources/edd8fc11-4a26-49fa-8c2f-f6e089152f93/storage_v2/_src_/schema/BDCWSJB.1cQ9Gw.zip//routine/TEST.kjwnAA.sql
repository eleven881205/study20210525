create procedure Test(p_username in varchar2, p_displayname out varchar2) is
 l_count number:=0; 

begin
    select  count(*) into l_count  from sysuser s where logonname =p_username;
    
    if(l_count=0) then
          p_displayname:='没有找到';
    else
         select  s.displayname into p_displayname  from sysuser s where logonname =p_username;
    end if;

   
end Test;
/

