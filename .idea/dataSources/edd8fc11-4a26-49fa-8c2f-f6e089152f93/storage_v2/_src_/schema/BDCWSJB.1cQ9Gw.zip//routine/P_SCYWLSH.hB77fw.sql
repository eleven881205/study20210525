create procedure p_scywlsh is

mysql varchar(100);
begin

  mysql:='drop sequence SEQ_YWLSH';
  execute immediate mysql;


  mysql:='create  sequence SEQ_YWLSH minvalue 1  maxvalue 99999 start with 1 increment by 1 cache 10';
  execute immediate mysql;

end p_scywlsh;
/

