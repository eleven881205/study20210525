create procedure p_scyylsh(p_cae007 in varchar2,p_sab100 in varchar2,p_cae015 out varchar2,p_aae013 out varchar2) is

 --上午最大预约流水号
 l_cae015_sw number:=30;

 --下午最大预约流水号
 l_cae015_xw number:=30;

 l_ny varchar2(10);

 l_time number;
 l_cae007 date;

 l_cae015 number:=1;

begin

    l_cae007:=to_date(p_cae007,'yyyy-mm-dd hh24:mi:ss');

    l_ny := to_char(l_cae007,'YYYYMMDD');

    l_time:=to_number(to_char(l_cae007 ,'hh24'));


    if(l_time<12) then
       l_ny:=l_ny ||'SW';
       select nvl(max(to_number(substr(cae015,11,3))),0) into l_cae015 from ce03  where cae015 like l_ny||'%';
       if(l_cae015>=l_cae015_sw) then
          p_cae015:=0;
          p_aae013:='今天上午预约号已满，请下午再预约';
       else
          p_cae015 := l_cae015 + 1;
          p_aae013:='无';

          if(to_number(p_cae015)<10) then
              p_cae015 :='00'||p_cae015;
          elsif (to_number(p_cae015)<100) then
              p_cae015 :='0'||p_cae015;
          end if;

          p_cae015 :=to_char(l_cae007,'yyyymmdd')|| 'SW' ||p_cae015 ;
       end if;
    else
       l_ny:=l_ny ||'XW';

       select nvl(max(to_number(substr(cae015,11,3))),0) into l_cae015 from ce03  where cae015 like l_ny||'%';
        if(l_cae015>=l_cae015_xw) then
           p_cae015:=0;
           p_aae013:='今天预约号已满，请明天再预约';
       else
          p_cae015 := l_cae015 + 1;
          p_aae013:='无';

          if(to_number(p_cae015)<10) then
              p_cae015 :='00'||p_cae015;
          elsif (to_number(p_cae015)<100) then
              p_cae015 :='0'||p_cae015;
          end if;

          p_cae015 :=to_char(l_cae007,'yyyymmdd')|| 'XW' ||p_cae015 ;

       end if;
    end if;

end p_scyylsh;
/

