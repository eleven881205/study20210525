create view V_BDC_CFXX as
select
  b.BDCDYH, --不动产单元号
  b.YWH, --业务号
  b.CFJG, --查封机关
  b.CFLX, --查封类型
  b.CFWH, --查封文号
  b.CFQSSJ, --查封起始时间
  b.CFJSSJ,--查封结束时间
  b.CFFW,--查封范围
  b.QXDM,--区县代码
  b.DJJG, --登记机构
  b.DBR, --登簿人
  b.DJSJ, --登记时间
  b.JFYWH, --解封业务号
  b.JFJG, --解封机关
  b.JFWH, --解封文号
  b.JFDJSJ, --解封登记时间
  b.FJ, --附记
  b.QSZT, --权属状态
  b.BDCQZH, --不动产权证号
  b.TSRQ, --推送日期
  b.YCCLH, --预测测量号
  b.HH, --室号
  b.SCCLH --实测测量号

  from   BDC_CFDJ b
/

