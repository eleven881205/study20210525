create procedure p_gzbp(p_sab100 IN gzbpls.sab100%type) is
begin
   --修改acs5表数据
 -- update acs5
  --  set aaa104='1', aae036 = sysdate where sab100 = p_sab100;
  --插入bs01表数据
                    insert into bs01
            (sae004,
             sab100,
             aae011,
             aae036,
             Aae102,
             Sac100,
             Sae007,
             Sld012)
            SELECT sae004,
                   sab100,
                   aae011,
                   aae036,
                   Aae102,
                   Sac100,
                   Sae007,
                   Sld012
              FROM gzbpls
             where sab100 = p_sab100;
   --插入bs02表数据
    insert into bs02
   (sae004, Functionid, Aad030, Bss001, Qdesc, Comments, Sae007)
   SELECT sae004, Functionid, Aad030, Bss001, Qdesc, Comments, Sae007
     FROM gzbpls
    where sab100 = p_sab100;
   delete from gzbpls;
 --  commit;
end p_gzbp;

/

