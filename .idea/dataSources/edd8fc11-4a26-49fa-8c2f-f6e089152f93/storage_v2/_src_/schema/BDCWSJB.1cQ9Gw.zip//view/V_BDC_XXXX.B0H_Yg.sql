create view V_BDC_XXXX as
select
  b.BDCDYH, --不动产单元号
  b.YWH ，--
  b.QLLX,  --权利类型
  b.DJLX,   --登记类型
  b.DJYY,   --登记原因
  b.FDZL,  --房地坐落
  b.TDSYQR, --土地使用权人
  b.DYTDMJ,  --独用土地面积
  b.FTTDMJ, --分摊土地面积
  b.TDSYQSSJ, --土地使用起始时间
  b.TDSYJSSJ, --土地使用结束时间
  b.FDCJYJG,  --房地产交易价格
  b.GHYT,  --规划用途
  b.FWXZ,  --房屋性质
  b.FWJG, --房屋结构
  b.SZC, --所在层
  b.ZCS,  --总层数
  b.JZMJ, --建筑面积
  b.ZYJZMJ, --专有建筑面积
  b.FTJZMJ,  --分摊建筑面积
  b.JGSJ, --竣工时间
  b.BDCQZH, --不动产权证号
  b.QXDM, --区县代码
  b.DJJG, --登记机构
  b.DBR, --登记人
  b.DJSJ, --登记时间
  b.FJ, --附记
  b.QSZT, --权属状态
  b.DH, --栋号
  b.DYH, --单元号
  b.FH, --房号
  b.DSCS, --地上层数
  b.DXCS, --地下层数
  b.MYC, --名义层
  b.FWLX, --房屋类型
  b.HX, --户型
  b.HXJG, --户型结构
  b.REMARK,--备注
  b.TDSYQMJ, --土地使用权面积
  b.TDSYQX, --土地使用期限
  b.isdz,
  b.DQ,  --东墙
  b.XQ, --西墙
  b.NQ, --南墙
  b.BQ,    --北墙
  b.TDYT, --土地用途
  b.TDQLXZ, --土地权利性质
  b.YTDZH, --土地证号
  b.ISBLFLAG, --是否补录，1：是，0：否
  b.ISGYZD, --是否共有宗地，1：是，0：否
  b.TDYT1, --土地用途1
  b.TDSYQX1, --土地使用期限1
  b.TDSYJSSJ1, --土地使用结束时间
  b.HSXQ,  --户室详情
  b.CLH, --测量号
  b.HH, --室号
  b.TSRQ --推送日期
from BDC_FDCQ2 b
/

