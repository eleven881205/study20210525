create procedure mybatisTest(p_cae001 in varchar2,p_result out varchar2) is
 l_count number:=0;

begin
    select  count(*) into l_count from ce01 where  cae001 =p_cae001;

    if(l_count=0) then
          insert into MYBATIS(CAE005, AAE013) values(p_cae001,'没有找到相应记录');
          p_result:='失败';
    else
         insert into MYBATIS(CAE005, AAE013) values(p_cae001,'找到相应记录');
         p_result:='成功';
    end if;


end mybatisTest;
/

