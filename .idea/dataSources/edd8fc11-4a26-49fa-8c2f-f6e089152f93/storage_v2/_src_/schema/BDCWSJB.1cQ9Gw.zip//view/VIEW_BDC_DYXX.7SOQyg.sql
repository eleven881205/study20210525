create view VIEW_BDC_DYXX as
select
b.YWH,  --业务号
b.BDCDYH, --不动产单元号
b.BDCDJZMH, --不动产登记证明号
b.QLRMC,  --权利人名称
b.YWRMC,  --义务人名称
b.YWRZJH,  --义务人证件号
b.ZWRMC,  --债务人名称
b.DYBW,  --抵押部位
b.DYSW,  --抵押顺位
b.DYDJSJ,  --抵押登记时间
b.BDBZZQSE,  --被担保主债权数额
b.ZGZQSE,  --最高债权数额
b.ZWLXQSSJ,  --债务履行起始时间c
b.ZWLXJSSJ,  --债务履行结束时间
b.QSZT,  --权属状态 1:有效 2:注销
b.ZXDYYWH,  --注销抵押业务号
b.ZXSJ  --注销时间

  from   view_bdcapp_dyxx@BDCAPPZJK b
/

