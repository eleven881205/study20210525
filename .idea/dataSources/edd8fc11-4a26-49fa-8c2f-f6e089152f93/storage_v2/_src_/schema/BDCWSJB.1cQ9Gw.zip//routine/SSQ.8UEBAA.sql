create function ssq(money in varchar2 --长度
                                    ) return varchar2 is



   aa VARCHAR2(3) :='1';
begin


  return '';
end ssq;

/

