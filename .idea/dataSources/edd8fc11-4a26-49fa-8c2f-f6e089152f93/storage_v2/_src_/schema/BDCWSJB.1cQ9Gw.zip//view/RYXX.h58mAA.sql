create view RYXX as
select "AAB001","AAC001","AAC147","AAC003","XB","AAC006","AAC007","AAC010","AAE200","RYLB","BZLX","AIC162","TXF","GZ1409","GZ2014","GZ2015","MZ","TXZWZB","ZZZWZB","GZNX" from (
  select aab001,aac001,aac147,aac003,(select aaa103 from aa10 where aaa100 = 'AAC004' and aaa102 = t.aac004 ) xb,
     aac006,decode(lengthb(aac007),6,substr(aac007,1,4)||'年'||substr(aac007,5,2)||'月',aac007) as aac007,aac010,aae200,(select aaa103 from aa10 where aaa100 = 'AAC191' and aaa102 = t.aac191 ) rylb ,
        (select aaa103 from aa10 where aaa100 = 'AAF022' and aaa102 = t.aaf022 ) bzlx ,decode(lengthb(aic162),6,substr(aic162,1,4)||'年'||substr(aic162,5,2)||'月',aic162) as aic162,  (nvl(jbtxf,0) + nvl(txbt,0)) txf,
    null as gz1409,null as gz2014,null as gz2015 , (select aaa103 from aa10 where aaa100 = 'AAC005' and aaa102 = t.aac005 ) mz,
   decode(aac191,
              1,(select aaa103 from aa10 where aaa100 = 'AAC219' and aaa102 = t.aac219),
              2,(select aaa103 from aa10 where aaa100= 'AAC015' and aaa102 = t.aac015) ,
              3,(select aaa103 from aa10 where aaa100= 'AAC195' and aaa102 = t.aac195) ,
              4,(select aaa103 from aa10 where aaa100= 'AAC197' and aaa102 = t.aac197) ,
              5,(select aaa103 from aa10 where aaa100= 'AAC216' and aaa102 = t.aac216) ,
              '') txzwzb,null as zzzwzb,
        (case when aae200 != 0 then case when trunc(aae200 / 12) != 0 then trunc(aae200 / 12) || '年' || mod(aae200, 12) || '个月'   else   mod(aae200, 12) || '个月'    end     else aae200||''  end ) gznx
       from txcj t
  union all
  select aab001,aac001,aac147,aac003,(select aaa103 from aa10 where aaa100 = 'AAC004' and aaa102 = t.aac004 ) xb,
         aac006,decode(lengthb(aac007),6,substr(aac007,1,4)||'年'||substr(aac007,5,2)||'月',aac007) as aac007,aac010,aae200,(select aaa103 from aa10 where aaa100 = 'AAC191' and aaa102 = t.aac191 ) rylb ,
        (select aaa103 from aa10 where aaa100 = 'AAF022' and aaa102 = t.aaf022 ) bzlx ,
         null as txf,null as aic162,gz1409,gz2014,gz2015 ,(select aaa103 from aa10 where aaa100 = 'AAC005' and aaa102 = t.aac005 ) mz ,
   decode(aac191,
              1,(select aaa103 from aa10 where aaa100 = 'AAC219' and aaa102 = t.aac219) || (select aaa103 from aa10 where aaa100= 'AAC220' and aaa102 = t.aac220) || (select aaa103 from aa10 where aaa100= 'AAC221' and aaa102 = t.aac221),
              2, (select aaa103 from aa10 where aaa100= 'AAC015' and aaa102 = t.aac015) || (select aaa103 from aa10   where aaa100 = 'AAC192'  and aaa102 = t.aac192)  ,
              3,(select aaa103 from aa10 where aaa100= 'AAC195' and aaa102 = t.aac195)  || (select aaa103 from aa10 where aaa100= 'AAC196' and aaa102 = t.aac196) ,
              4,(select aaa103 from aa10 where aaa100= 'AAC197' and aaa102 = t.aac197)  || (select aaa103 from aa10 where aaa100= 'AAC198' and aaa102 = t.aac198) ,
              5,(select aaa103 from aa10 where aaa100= 'AAC216' and aaa102 = t.aac216)  || (select aaa103 from aa10 where aaa100= 'AAC217' and aaa102 = t.aac217) ,
              '') zzzwzb,null as txzwzb,
        (case when aae200 != 0 then case when trunc(aae200 / 12) != 0 then trunc(aae200 / 12) || '年' || mod(aae200, 12) || '个月'  else   mod(aae200, 12) || '个月'    end     else aae200||''  end ) gznx
  from zzcj t)
/

