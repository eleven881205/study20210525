create trigger TRG_CF01
    before insert
    on CF01
    for each row
BEGIN
     IF INSERTING THEN
        :NEW.caf017 := get_chinese(:NEW.caf001,2);
    END IF;
END;

/

