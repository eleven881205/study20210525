create view V_BDC_RYBDCXX as
select t1.BDCQZH GYRBDCQZH, --共有人不动产权证号
       t2.BDCQZH BDCQZH, --不动产权证号
       t1.QLRMC , --共有人名称
       t1.ZJZL,   --证件种类
       t1.ZJH,    --证件号
       t1.FZJG,--发证机关
       t1.SSHY,--所属行业
       t1.GJ,--国家/地区
       t1.HJSZSS, --户籍所在省市
       t1.XB,     --性别
       t1.DH,     --电话
       t1.DZ,     --地址
       t1.YB,     --邮编
       t1.GZDW,   --工作单位
       t1.DZYJ,   --电子邮件
       t1.QLBL,    --权利比例
       t1.GYFS,    -- 共有方式
       t1.GYQK,    -- 共有情况
       t1.YWH,--业务号
       t1.BDCQZH_NIAN,  --年份
       t1.BDCQZH_JGJC,--机构简称
       t1.BDCQZH_NO,--证书号
       t1.DBR,     --登薄人
       t1.DJSJ,   --登薄时间
       t1.DJJG,   --登记机构
       t1.QXDM,  -- 区县代码
       t1.TSRQ --推送日期
 from BDC_QLR t1,
     (select bdcqzh,ywh from BDC_FDCQ2 x1
       where  ywh =(select max(ywh) from BDC_FDCQ2 x2 where x1.bdcqzh=x2.bdcqzh) and QSZT='1') t2
  where t1.ywh=t2.ywh
/

